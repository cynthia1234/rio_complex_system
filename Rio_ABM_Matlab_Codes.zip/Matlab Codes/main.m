%% Main function
gen=30;
urb_rate=0.01;
agri_rate=0.005;
mang_rate=0.02;
slr_rate=1;
flood_rate= 0;
%run simulation 
[Mangrove, Urban, Agriculture, Vegetation, Sea] = rio_simulation(gen, urb_rate,agri_rate, mang_rate, slr_rate, flood_rate);
%visualise 
visualise(Mangrove, Urban, Agriculture,Vegetation, Sea, transit, protect)

%Calculate summary data
veg_pop = cellfun(@nnz,Vegetation);
urb_pop=cellfun(@nnz,Urban);
agri_pop=cellfun(@nnz,Agriculture);
mangrove_pop=cellfun(@nnz,Mangrove);
other_veg_pop=veg_pop-mangrove_pop;

% plot summary
figure
subplot(1,2,1)
plot(mangrove_pop)
title({'Mangrove Population', ['urb rate=' num2str(urb_rate) ', agri rate=' num2str(agri_rate) ', mang rate=' num2str(mang_rate)]});
subplot(1,2,2)
all_pop=cat(2,other_veg_pop,mangrove_pop,urb_pop,agri_pop);
area(all_pop)
legend('other vegetation','mangrove','urban','agriculture')
title(['Landuse Change Over Time']);

plot only mangrove area
figure
plot(mangrove_pop)
title('Mangrove Population over time')



%Create a loop to change mangrove resistance
% urb_rate=0.005;
% [Mangrove, Urban, Agriculture, Vegetation, Sea] = rio_simulation(gen, urb_rate,agri_rate, mang_rate, slr_rate, flood_rate);
% m1=cellfun(@nnz,Mangrove);
% 
% urb_rate=0.01;
% [Mangrove, Urban, Agriculture, Vegetation, Sea] = rio_simulation_draft_2(gen, urb_rate,agri_rate, mang_rate, slr_rate, flood_rate);
% m2=cellfun(@nnz,Mangrove);
% 
% urb_rate=0.015;
% [Mangrove, Urban, Agriculture, Vegetation, Sea] = rio_simulation_draft_2(gen, urb_rate,agri_rate, mang_rate, slr_rate, flood_rate);
% m3=cellfun(@nnz,Mangrove);
% 
% figure
% t=1:30;
% plot(t,m1,t,m2,t,m3)
% title('Mangrove Population Over Time: Urb Rate')
% legend('urb rate = 0.5%','urb rate = 1%','urb rate = 1.5%')

