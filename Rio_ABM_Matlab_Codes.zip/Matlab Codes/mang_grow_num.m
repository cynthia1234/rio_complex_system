%% function to calculate the growth rate 
function growth_num = mang_grow_num(urban, agri, mangrove, slr1, slr2, slr3, k) %constant growth k = constant growth + health index 
        %calculate proximity to urban
        urb_prox=bwdist(urban);
          
        % note: incorporate waterway masks, we assume nutrients
        % can travel on water
        waterway=read_mask('waterway.png',300);
        %set extent to be radius 10
        se=strel('rectangle',[50,100]);
        agri_extent=imdilate(agri,se);

        water_agri= waterway + agri;
        water_agri(water_agri>1)=1;%clip max value to 1
        water_agri(agri_extent ~= 1)=0;
        % proximity to agriculture_waterway
        agri_prox=bwdist(water_agri);
        
        %calculate urban and agriculture clusters
        urb_cluster=cluster_size(urban);
        agri_cluster=cluster_size(agri);

        %calculate agriculture
        pollution =  impact_func(urb_prox, urb_cluster, 20);
        nutrient = 0.5*impact_func(urb_prox, urb_cluster, 20) + 0.5*impact_func(agri_prox, agri_cluster, 20);

        %calculate sea level rise risk 
        tidal= imgaussfilt(slr1.*1,10)/3 + imgaussfilt(slr2.*1,10)/3 + imgaussfilt(slr3.*1,10)/3 ;

        % calculate the overall growth rate
        idx=find(mangrove==1);
        mang_arr=mangrove(:); 
        nutrient_arr=nutrient(:);
        pollution_arr=pollution(:);
        tidal_arr=tidal(:);

        mang_pop=nnz(mangrove);
        nutrient_avg=sum(nutrient_arr(idx))/mang_pop;
        pollution_avg=sum(pollution_arr(idx))/mang_pop;
        tidal_avg= sum(tidal_arr(idx))/mang_pop;
        health_index=(nutrient_avg-pollution_avg)*(1-tidal_avg);
        growth_rate= k + health_index; 
        growth_num=growth_rate*mang_pop; %number of new mangroves to grow 
        growth_num=round(growth_num);
 
  %% impact_func
     %risk calculation to take into account of distance matrix and cluster matrix
    function [risk_matrix] = impact_func(dist_matrix, cluster_matrix, smooth_factor)
    %smooth dist_matrix
    dist_smooth= imgaussfilt(dist_matrix, smooth_factor/2);
    %smooth cluster_matrix
    cluster_smooth = imgaussfilt(cluster_matrix, smooth_factor);
    dist_inv= (dist_smooth+1).^(-1);
    risk_matrix = dist_inv.*cluster_smooth;
    end 
   end 