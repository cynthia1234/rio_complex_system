function [Mangrove, Urban, Agriculture, Vegetation, Sea] = rio_simulation(gen, urb_rate, agri_rate, mang_rate, slr_rate, flood_rate) %num of generations

%% Store matrix info for each time step in a cell
Mangrove= cell(gen,1);
Urban = cell(gen,1);
Agriculture = cell(gen,1);
Sea=cell(gen,1);
Vegetation=cell(gen,1);

%% Intialise mangrove and urban population
[info,protect,mangrove,transit, slr1,slr2,slr3]= map_init_Rio();
[m,n]=size(info);
%read info matrix
[veg, agri, urban]=read_info(info);
%% Derive sea matrix
%using info matrix to derive sea matrix
sea=zeros(m,n);
sea(300:m,:)=1; %below row 300 can be sea
%mask out using base
sea(info~=0)=0;

%% Record data 
Mangrove{1}=mangrove;
Vegetation{1}=veg;
Urban{1}=urban;
Sea{1}=sea;
Agriculture{1}=agri;

%% ----- put things into a loop ------

for t=2:gen 
%%     update proximity for urbanisation and mangrove every 5 iterations
    if mod(t,3)==2 
        % calculate proximity matrices
        sea_prox=prox_smooth(sea);
        urb_prox=prox_smooth(urban);
        transit_prox=prox_smooth(transit);
        mang_prox=prox_smooth(mangrove);
        agri_prox=prox_smooth(agri);     
    end 
    
    %% sea level rise 
    % input slr_rate = sea front expand by x grids 
    se=strel('rectangle',[slr_rate,slr_rate]);
    sea=imdilate(sea,se);
    info(sea==1)=0;
    Sea{t}=sea; 
    
    %% flood chance according to flood_rate
    random = rand(1,1);
    if random < flood_rate
        info(slr1==1)=4; %4 means destroyed land 
        mangrove(info==4)=0;%mangrove dies 
        disp(['flood, t=' num2str(t)])
    end 
       
    %% grow mangroves  
    
    %update according to info matrix
    [veg, agri, urban]=read_info(info);
    mangrove(info~=3)=0;
    sea(info~=0)=0;
    
    %calculate new mangrove number 
    n_mang = mang_grow_num(urban, agri, mangrove, slr1, slr2, slr3, mang_rate);
    
    %grow mangrove
    i_hab_mang=i_hab_func(-1,-1,2,2); %transit, urb, sea, mang
    
    % incorporate waterway masks
    waterway=read_mask('waterway.png',300);
    %set extent
    se=strel('rectangle',[50,200]);
    extent=imdilate(mangrove,se);
    mang_water= waterway + mangrove;
    mang_water(mang_water>1)=1;%clip max value to 1
    mang_water(extent ~= 1)=0;
    
    %update i_hab_mang with edge of mangrove & waterway
    se=strel('rectangle',[5,5]);
    mang_dilate=imdilate(mang_water,se);
    edge_mang=mang_dilate-mangrove;
    %cannot grow elsewhere than edge 
    i_hab_mang(edge_mang~=1)=-2; 
    
    % sedimentation related to rate of urbanisation
    sediment=zeros(m,n);
    sediment((edge_mang==1) & (sea==1))=10*urb_rate;
    i_hab_mang=i_hab_mang+sediment; 
    
    %grow mangroves
    mangrove= grow_func(n_mang,i_hab_mang,mangrove);  
    %update info
    info(mangrove==1)=3;
    %% grow agriculture 
    i_hab_agri=i_hab_func(1,0,0,0); %transit, urb, sea, mang
    
    %cannot have agriculture in protected area or sea 
    i_hab_agri(protect==1)=-2;
    i_hab_agri(sea==1)=-2;
    
    %convert landuse into agriculture
    agri_n=round(agri_rate*nnz(agri));
    agri = grow_func(agri_n, i_hab_agri, agri); %new places for agriculture landuse 
    
    %update info
    info(agri==1)=2;   
    
    %% grow urban area   
    i_hab_urb= i_hab_func(1,1,0,0);  %transit, urb, sea, mang
    
    %cannot have urban in protected area or sea or agriculture area
    i_hab_urb(protect==1)=-2;
    i_hab_urb(sea==1)=-2;
    i_hab_urb(agri==1)=-2;
    
    %urban expand 
    n_urb=round(urb_rate*nnz(urban));
    urban = grow_func(n_urb, i_hab_urb, urban);
    
    info(urban==1)=1;
    
    %% record results
    
    [veg, agri, urban]=read_info(info);
    mangrove(info~=3)=0;
    sea(info~=0)=0;
    
    Mangrove{t}=mangrove;
    Urban{t}=urban;
    Agriculture{t}=agri;
    Vegetation{t}=veg;
    Sea{t}=sea; 

end %end of loop   

%% Some functions 
    %function to calculate the habitat index
        %maybe add the water map here!
    function i_hab = i_hab_func(b1,b2,b3,b4) %beta = weights \
        i_hab = zeros(m,n);
        %exponentially decay with different lamdas
        transit_exp = exp(-1*transit_prox/2); %faster decay
        urb_exp=exp(-1*urb_prox/2);
        sea_exp=exp(-1*sea_prox/2); 
        mang_exp=exp(-1*mang_prox/2);
        i_hab= b1*transit_exp+ b2*urb_exp + b3*sea_exp + b4*mang_exp;  

        %cannot grow in places where there is road,farm,mangrove,etc. 
        i_hab(transit==1)=-2;%transit
        i_hab(urban==1)=-2; %urban
        i_hab(info==0)=-2; %out-of-boundary
    end 

%% grow_func to grow community according to growth_rate and i_habitat
%input: n=new members to grow, i_hab=habitat index, mask=where can cells grow 
    function population_new= grow_func(n,i_hab,population_matrix)         
        %threshold for habitat is 0
        n1=length(find(i_hab> 0));
        n2=min(n,n1);
        
        pop_arr=population_matrix(:);
        if n2 > 0
            [max_val,idx]=maxk(i_hab(:),n2);
            pop_arr(idx)=1;
        end
        population_new=reshape(pop_arr,size(population_matrix));
    end %end of grow_func   

%% function to calculate distance and smooth it
    function smooth=prox_smooth(input)
        prox=bwdist(input);
        smooth=imgaussfilt(prox,10);
    end 
%% funciton to read info_matrix
    function [veg, agri, urban]=read_info(info)
        urban=zeros(m,n);
        urban(info==1)=1;
        agri=zeros(m,n);
        agri(info==2)=1;
        veg=zeros(m,n);
        veg(info==3)=1;
    end 


end %end of entire script function
