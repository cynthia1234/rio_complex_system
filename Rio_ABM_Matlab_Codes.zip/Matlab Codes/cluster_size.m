 %% cluster_size function
    %input = population (logical matrix)
    %output = numeric matrix indicating cluster size each cell belongs to,
    %applied Gaussian smoothing (to indicate diffusion) 
      function output = cluster_size(input_matrix)
        
        [m,n]=size(input_matrix);
        out_arr=zeros(m*n,1); 
        
        CC=bwconncomp(input_matrix,8); %find connected cells
        S=regionprops( 'table', CC,'Area');%calculate connected area
            for i=1:size(S.Area,1) %replace array value with connected area 
                idx_list= CC.PixelIdxList{i};
                out_arr(idx_list)=S.Area(i);
            end 
         out= reshape(out_arr,m,n);
         %normalize
         output=normalize(out,'range'); %normalise to [0,1]
      end 
