function []= visualise(Mangrove, Urban, Agriculture, Vegetation,Sea, Road, Protected)
gen=size(Mangrove,1);

figure
pause(4)
for t=1:gen
        spy(Urban{t},'k');
        hold on   
        spy(Vegetation{t},'g');
        spy(Agriculture{t},'y');
        spy(Road,'r');
        spy(Protected,'c');
        spy(Mangrove{t},'m');
        spy(Sea{t},'b');
        hold off
    legend('urban','vegetation','agriculture','transit','protected','mangrove','sea')
    title(['t=' num2str(t) ', urb rate=1%, agri= 0.5%, mangrove=2%, slr=1, flood=5%'])
    drawnow 
    pause(0.5)
    
end


end 