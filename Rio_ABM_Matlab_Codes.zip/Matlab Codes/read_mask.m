%masked with black have value 1
    % connectivity_threshold delete "noisy" entries 
function I2 = read_mask(image_input,conn_thres)
%read picture
I=imread(image_input);
I=rgb2gray(I);
I=imbinarize(I); %change to B&W
I=-1*I+1; %convert 1 to 0
I2=bwareaopen(I,conn_thres);
end 