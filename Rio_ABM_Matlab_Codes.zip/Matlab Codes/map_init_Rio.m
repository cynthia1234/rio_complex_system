function [info,protect,mangrove,transit, slr1,slr2,slr3]= map_init_Rio()
%% read masks 
%info matrix
base=read_mask('base.png',300);
urban=read_mask('urban.png',10);
agriculture=read_mask('agriculture.png',10);
vegetation = read_mask('vegetation.png',10);
    %store information
    info=zeros(size(base));
    info(urban==1)=1;
    info(agriculture==1)=2;
    %rest= vegetation 
    info(base~=0 & info==0)=3;
    %boundary, sea or other cities 
    info(base==0)=0;

%other matrix
mangrove=read_mask('mangrove.png',10);
protect=read_mask('protect.png',10);
transit=read_mask('transit.png',10);
slr1=read_mask('slr1.png',10);
slr2=read_mask('slr2.png',10);
slr3=read_mask('slr3.png',10);
end 